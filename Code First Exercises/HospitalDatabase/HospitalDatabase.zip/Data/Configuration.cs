﻿namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public static string ConntectionString { get; set; } = "Server=HELLYSCOMP\\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}