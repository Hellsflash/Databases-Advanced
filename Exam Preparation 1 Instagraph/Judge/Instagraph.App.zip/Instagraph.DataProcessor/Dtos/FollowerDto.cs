﻿namespace Instagraph.DataProcessor.Dtos
{
    public class FollowerDto
    {
        public string User { get; set; }

        public string Follower { get; set; }
    }
}