﻿using System;

namespace P02.DatabaseFirst
{
    internal class StartUp
    {
        private static void Main(string[] args)
        {
        }
    }
}