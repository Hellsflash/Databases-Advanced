namespace Stations.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-743NOB2\SQLEXPRESS;Database=Stations;Trusted_Connection=True";
    }
}